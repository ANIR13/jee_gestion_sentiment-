package miniXML;

import java.awt.Graphics;
import java.util.List;

import javax.swing.JPanel;

public class JanglePanel extends JPanel{
	private Forme forme;
	
	private FormeRect rect;
	
	private XMLReader xmlReader;

	private List<Forme> formes;
	
	private List<FormeRect> rects ;
	
	public void reinitAll(){
		formes = xmlReader.getformes();
	}
	public JanglePanel() {

		xmlReader = new XMLReader();

		formes = xmlReader.getformes();
		
        rects = xmlReader.getformeRects();
        
		// animal par d�faut
		forme = formes.get(1);
//		
		rect= rects.get(1);

	}
	public void choisirRect(int idRect) {
		rect = rects.get(idRect);
	}
	
	public void choisirForme(int idforme) {
		forme = formes.get(idforme);
	}

	public void paintComponent(Graphics g) {
		
		for(int i=0; i<formes.size();i++) {
			choisirForme(i);
			System.out.println(forme);	
g.fillOval(forme.getCx(),forme.getCy(), forme.getRayon(), forme.getRayon());
//g.drawString(forme.getId(),forme.getCx()-2,forme.getCy()-2);

		}
		for(int i=0; i<rects.size();i++) {
			choisirRect(i);
			System.out.println(rect);	
g.fillRect(rect.getX(),rect.getY(), rect.getWidth(), rect.getHeight());
//g.drawString(rect.getId(),forme.getCx()-2,forme.getCy()-2);

//System.out.println(forme);
		}
		
	}
	public Forme getForme() {
		return forme;
	}
	public void setForme(Forme forme) {
		this.forme = forme;
	}
	public List<FormeRect> getRect() {
		return rects;
	}
	public void setRect(List<FormeRect> rects) {
		this.rects = rects;
	}


}
