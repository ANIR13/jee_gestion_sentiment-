package miniXML;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.*;


/**
 * Permet de parser le fichier XML pr�sentant les animaux et leurs d�placements
 * 
 * @author Tarik BOUDAA
 *
 */
public class XMLReader {

	private final DocumentBuilderFactory factory = DocumentBuilderFactory
			.newInstance();

	private DocumentBuilder builder;
	private Document document;
	private Element racine;

	/**
	 * Constructeur qui initialise le parseur DOM et r�cup�re la racine du
	 * document
	 */
	public XMLReader() {

		try {

			builder = factory.newDocumentBuilder();

			document = builder.parse(new File("cercle.xml"));

			racine = document.getDocumentElement();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * Construit une liste d'animaux � partir de l'arbre DOM
	 * 
	 * @return liste des animaux
	 */
	public List<Forme> getformes() {

		// Pour stocker la liste des animaux
		List<Forme> formes = new ArrayList<Forme>();
		// les animaux sont dans cette liste
		NodeList nodList = racine.getChildNodes();
		Forme forme;
		Node listNodElm;
		for (int i = 0; i < nodList.getLength(); i++) {

			listNodElm = nodList.item(i);

			if (listNodElm.getNodeType() == Node.ELEMENT_NODE) {

				if(listNodElm.getNodeName()== "Forme") {
//				String id = Integer.parseInt(((Element) listNodElm)
//						.getAttribute("id"));

				String id = ((Element) listNodElm).getAttribute("id");
				forme = new Forme(id);

				// On r�cup�re les positions
				NodeList nodelist = listNodElm.getChildNodes();

				for (int j = 0; j < nodelist.getLength(); j++) {

					if (nodelist.item(j).getNodeType() == Node.ELEMENT_NODE ) {
						
						if(nodelist.item(j).getNodeName()=="rayon"){
							
						int r = Integer.parseInt(((Element) nodelist.item(j))
								.getAttribute("r"));
						forme.setRayon(r);
						}
						
						if(nodelist.item(j).getNodeName()=="centre"){
						int cx = Integer.parseInt(((Element) nodelist.item(j))
								.getAttribute("cx"));
						int cy = Integer.parseInt(((Element) nodelist.item(j))
								.getAttribute("cy"));

						forme.setCx(cx);
						forme.setCy(cy);
						}
						
						
						
					}
				}
//				forme.setRayon(r);
//				forme.setCx(cx);
//				forme.setCy(cy);
				formes.add(forme);

			}

		}
		}
		return formes;

	}

	public List<FormeRect> getformeRects() {

		// Pour stocker la liste des animaux
		List<FormeRect> rects = new ArrayList<FormeRect>();
		// les animaux sont dans cette liste
		NodeList nodList = racine.getChildNodes();
		FormeRect rect;
		Node listNodElm;
		for (int i = 0; i < nodList.getLength(); i++) {

			listNodElm = nodList.item(i);

			if (listNodElm.getNodeType() == Node.ELEMENT_NODE) {

				if(listNodElm.getNodeName()== "rect") {
//				String id = Integer.parseInt(((Element) listNodElm)
//						.getAttribute("id"));

				String id = ((Element) listNodElm).getAttribute("id");
				rect = new FormeRect(id);

				// On r�cup�re les positions
				NodeList nodelist = listNodElm.getChildNodes();

				for (int j = 0; j < nodelist.getLength(); j++) {

					if (nodelist.item(j).getNodeType() == Node.ELEMENT_NODE ) {
						
						if(nodelist.item(j).getNodeName()=="prop"){
					    int h = Integer.parseInt(((Element) nodelist.item(j))
							  .getAttribute("height"));	
						int w = Integer.parseInt(((Element) nodelist.item(j))
								.getAttribute("width"));
						rect.setHeight(h);
						rect.setWidth(w);
						}
						
						if(nodelist.item(j).getNodeName()=="position"){
						int x = Integer.parseInt(((Element) nodelist.item(j))
								.getAttribute("x"));
						int y = Integer.parseInt(((Element) nodelist.item(j))
								.getAttribute("y"));

						rect.setX(x);
						rect.setY(y);
						}
						
						
						
					}
				}
//				forme.setRayon(r);
//				forme.setCx(cx);
//				forme.setCy(cy);
				rects.add(rect);

			}

		}
		}
		return rects;

	}
	
}
