package miniXML;

public class Forme {

	private String id;
	private int r,cx,cy;
	
	public Forme() {
		
	}
	public Forme(String id) {
		this.id = id;
	}
	public Forme(String id, int rayon, int cx, int cy) {
		this.id = id;
		this.r = rayon;
		this.cx = cx;
		this.cy = cy;
	}
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public int getRayon() {
		return r;
	}
	public void setRayon(int rayon) {
		this.r = rayon;
	}
	public int getCx() {
		return cx;
	}
	public void setCx(int cx) {
		this.cx = cx;
	}
	public int getCy() {
		return cy;
	}
	public void setCy(int cy) {
		this.cy = cy;
	}
	@Override
	public String toString() {
		return "Forme [id=" + id + ", r=" + r + ", cx=" + cx + ", cy=" + cy + "]";
	}
	
}
