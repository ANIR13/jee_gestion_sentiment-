package miniXML;

public class FormeRect {
private String id;
private int x ,  y, width,height;


public FormeRect(String id) {
	this.id = id;
}
public FormeRect(String id, int x, int y, int width, int height) {
	
	this.id = id;
	this.x = x;
	this.y = y;
	this.width = width;
	this.height = height;
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public int getX() {
	return x;
}
public void setX(int x) {
	this.x = x;
}
public int getY() {
	return y;
}
public void setY(int y) {
	this.y = y;
}
public int getWidth() {
	return width;
}
public void setWidth(int width) {
	this.width = width;
}
public int getHeight() {
	return height;
}
public void setHeight(int height) {
	this.height = height;
}
@Override
public String toString() {
	return "FormeRect [id=" + id + ", x=" + x + ", y=" + y + ", width=" + width + ", height=" + height + "]";
}

}
