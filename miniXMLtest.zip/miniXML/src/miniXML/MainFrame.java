package miniXML;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainFrame extends JFrame implements ActionListener {
	 private JanglePanel janglePan= new JanglePanel();
	private JPanel menuPan = new JPanel();
	private JButton btn = new JButton("afficher XML");
//	private JLabel stateLabel = new JLabel("...........");
	Container c=getContentPane();
	public MainFrame() {
		c.add(menuPan);
	setTitle("Application XML Introduction");
	setSize(600, 500);
	c.add(btn);
	btn.addActionListener(this);
	menuPan.add(btn);
add(menuPan, BorderLayout.NORTH);

	setVisible(true);
	
}
	public static void main(String[] args) {
	
		MainFrame test=new MainFrame();
	}
	public void actionPerformed(ActionEvent ev) {
		 c.add(janglePan);
		 c.repaint();
c.validate();
	
	}
	
}
